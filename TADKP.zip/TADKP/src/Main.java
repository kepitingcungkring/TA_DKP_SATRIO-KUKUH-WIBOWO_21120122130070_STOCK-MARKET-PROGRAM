import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.Timer;

public class Main extends JFrame {
    private List<Stock> stocks;
    private List<JLabel> stockNameLabels;
    private List<JLabel> stockPriceLabels;
    private List<JLabel> stockArrowLabels;
    private JLabel ownedStocksLabel;

    public Main() {
        setTitle("Proyek Tugas Akhhir DKP");
        setSize(926, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        stocks = new ArrayList<>();
        stockNameLabels = new ArrayList<>();
        stockPriceLabels = new ArrayList<>();
        stockArrowLabels = new ArrayList<>();

        // Create stocks
        stocks.add(new Stock("Microsoft"));
        stocks.add(new Stock("Apple"));
        stocks.add(new Stock("Amazon"));
        stocks.add(new Stock("Facebook"));
        stocks.add(new Stock("Google"));
        stocks.add(new Stock("Netflix"));
        stocks.add(new Stock("Intel"));
        stocks.add(new Stock("Nintendo"));
        stocks.add(new Stock("Sony"));

        initComponents();
        updateStockPrices();
        updateOwnedStocks();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel stocksPanel = new JPanel();
        stocksPanel.setBackground(new Color(40, 40, 40));
        stocksPanel.setLayout(new GridLayout(0, 3, 10, 10));
        JScrollPane scrollPane = new JScrollPane(stocksPanel);
        scrollPane.setPreferredSize(new Dimension(550, 580));
        mainPanel.add(scrollPane, BorderLayout.WEST);

        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(40, 40, 40));
        infoPanel.setLayout(new BorderLayout());
        mainPanel.add(infoPanel, BorderLayout.CENTER);

        JLabel titleLabel = new JLabel("Pasar Saham Amerika Serikat");
        titleLabel.setForeground(Color.cyan);
        titleLabel.setFont(new Font("Bahnschrift", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        infoPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel ownedStocksPanel = new JPanel();
        ownedStocksPanel.setBackground(new Color(40, 40, 40));
        ownedStocksPanel.setLayout(new BorderLayout());
        infoPanel.add(ownedStocksPanel, BorderLayout.CENTER);

        ownedStocksLabel = new JLabel("Jumlah Saham yang Dimiliki: 0");
        ownedStocksLabel.setForeground(Color.YELLOW);
        ownedStocksLabel.setFont(new Font("Bahnschrift", Font.PLAIN, 18));
        ownedStocksLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        ownedStocksLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ownedStocksPanel.add(ownedStocksLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(40, 40, 40));
        buttonPanel.setLayout(new GridLayout(2, 1, 10, 10));
        infoPanel.add(buttonPanel, BorderLayout.SOUTH);

        JButton buyButton = new JButton("Beli Saham");
        buyButton.setBackground(Color.PINK);
        buyButton.setFont(new Font("Bahnschrift", Font.BOLD, 16));
        buyButton.setFocusPainted(false);
        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showBuyDialog();
            }
        });

        // Create buy button panel
        JPanel buyButtonPanel = new JPanel();
        buyButtonPanel.setBackground(new Color(40, 40, 40));
        buyButtonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buyButtonPanel.add(buyButton);
        buttonPanel.add(buyButtonPanel);

        JButton sellButton = new JButton("Jual Saham");
        sellButton.setBackground(Color.ORANGE);
        sellButton.setFont(new Font("Bahnschrift", Font.BOLD, 16));
        sellButton.setFocusPainted(false);
        sellButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSellDialog();
            }
        });

        // Create sell button panel
        JPanel sellButtonPanel = new JPanel();
        sellButtonPanel.setBackground(new Color(40, 40, 40));
        sellButtonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        sellButtonPanel.add(sellButton);
        buttonPanel.add(sellButtonPanel);

        // Create stock panels
        for (int i = 0; i < stocks.size(); i++) {
            JPanel stockPanel = new JPanel();
            stockPanel.setBackground(Color.BLACK);
            stockPanel.setLayout(new BorderLayout());
            stocksPanel.add(stockPanel);

            JLabel nameLabel = new JLabel(stocks.get(i).getName());
            nameLabel.setForeground(Color.WHITE);
            nameLabel.setFont(new Font("Bahnschrift", Font.BOLD, 18));
            nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
            stockPanel.add(nameLabel, BorderLayout.NORTH);
            stockNameLabels.add(nameLabel);

            JLabel priceLabel = new JLabel("Rp 0,00");
            priceLabel.setForeground(Color.WHITE);
            priceLabel.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
            priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
            stockPanel.add(priceLabel, BorderLayout.CENTER);
            stockPriceLabels.add(priceLabel);

            JLabel arrowLabel = new JLabel("▲");
            arrowLabel.setForeground(Color.GREEN);
            arrowLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            arrowLabel.setHorizontalAlignment(SwingConstants.CENTER);
            stockPanel.add(arrowLabel, BorderLayout.SOUTH);
            stockArrowLabels.add(arrowLabel);
        }

        JButton exitButton = new JButton("Keluar");
        exitButton.setBackground(Color.LIGHT_GRAY);
        exitButton.setFont(new Font("Bahnschrift", Font.BOLD, 22));
        exitButton.setFocusPainted(false);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(
                        Main.this,
                        "Apakah Anda yakin ingin keluar?",
                        "Keluar",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (option == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        mainPanel.add(exitButton, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private void updateStockPrices() {
        Timer timer = new Timer(1580, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (Stock stock : stocks) {
                    stock.updatePrice();
                    int index = stocks.indexOf(stock);
                    JLabel priceLabel = stockPriceLabels.get(index);
                    JLabel arrowLabel = stockArrowLabels.get(index);
                    priceLabel.setText(stock.getFormattedPrice());

                    if (stock.getPriceChange() >= 0) {
                        priceLabel.setForeground(Color.GREEN);
                        arrowLabel.setText("▲");
                        arrowLabel.setForeground(Color.GREEN);
                    } else {
                        priceLabel.setForeground(Color.RED);
                        arrowLabel.setText("▼");
                        arrowLabel.setForeground(Color.RED);
                    }
                }
            }
        });
        timer.setRepeats(true);
        timer.start();
    }

    private void updateOwnedStocks() {
        Timer timer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int totalOwnedStocks = stocks.stream().mapToInt(Stock::getQuantity).sum();
                ownedStocksLabel.setText("Jumlah Saham yang Dimiliki: " + totalOwnedStocks);
            }
        });
        timer.setRepeats(true);
        timer.start();
    }



    private void showBuyDialog() {
        String[] stockNames = stocks.stream().map(Stock::getName).toArray(String[]::new);
        String selectedStock = (String) JOptionPane.showInputDialog(this, "Pilih saham yang ingin Anda beli:",
                "Beli Saham", JOptionPane.PLAIN_MESSAGE, null, stockNames, stockNames[0]);

        if (selectedStock != null) {
            Stock stock = getStockByName(selectedStock);
            if (stock != null) {
                double currentPrice = stock.getPrice(); // Mengambil harga saham saat ini
                String formattedPrice = stock.getFormattedPrice(currentPrice); // Format harga dalam format mata uang

                int quantity = Integer.parseInt(JOptionPane.showInputDialog(this,
                        "Harga saham " + stock.getName() + ": " + formattedPrice +
                                "\n\nJumlah saham yang ingin Anda beli:", "Beli Saham", JOptionPane.PLAIN_MESSAGE));

                stock.buy(quantity);
                JOptionPane.showMessageDialog(this, "Berhasil membeli " + quantity + " saham " + stock.getName() + "!",
                        "Beli Saham", JOptionPane.INFORMATION_MESSAGE);
                String message = "Anda telah membeli saham " + stock.getName() +
                        " sebanyak " + quantity +
                        " bernilai " + stock.getFormattedPrice(currentPrice * quantity) + ".";
                JOptionPane.showMessageDialog(this, message, "Beli Saham", JOptionPane.INFORMATION_MESSAGE);

            }
        }
    }


    private void showSellDialog() {
        String[] stockNames = stocks.stream()
                .filter(stock -> stock.getQuantity() > 0)
                .map(Stock::getName).toArray(String[]::new);

        if (stockNames.length > 0) {
            String selectedStock = (String) JOptionPane.showInputDialog(this, "Pilih saham yang ingin Anda jual:",
                    "Jual Saham", JOptionPane.PLAIN_MESSAGE, null, stockNames, stockNames[0]);

            if (selectedStock != null) {
                Stock stock = getStockByName(selectedStock);
                if (stock != null) {
                    int quantity = Integer.parseInt(JOptionPane.showInputDialog(this,
                            "Jumlah saham " + stock.getName() + " yang ingin Anda jual:", "Jual Saham",
                            JOptionPane.PLAIN_MESSAGE));

                    if (stock.sell(quantity)) {
                        JOptionPane.showMessageDialog(this,
                                "Berhasil menjual " + quantity + " saham " + stock.getName() + "!", "Jual Saham",
                                JOptionPane.INFORMATION_MESSAGE);
                        String message = "Anda telah menjual saham " + stock.getName() +
                                " sebanyak " + quantity +
                                " bernilai " + stock.getFormattedPrice(stock.getCurrentPrice() * quantity) + ".";
                        JOptionPane.showMessageDialog(this, message, "Jual Saham", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(this,
                                "Anda hanya memiliki " + stock.getQuantity() + " saham " + stock.getName() + "!",
                                "Jual Saham", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Anda tidak memiliki saham yang dapat dijual!",
                    "Jual Saham", JOptionPane.ERROR_MESSAGE);
        }
    }



    private Stock getStockByName(String name) {
        return stocks.stream()
                .filter(stock -> stock.getName().equals(name))
                .findFirst()
                .orElse(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main();
            }
        });
    }

}
