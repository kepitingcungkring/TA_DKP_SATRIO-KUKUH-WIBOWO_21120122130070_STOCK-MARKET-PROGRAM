import java.text.DecimalFormat;
import java.util.Random;

class Stock {
    private String name;
    private double price;
    private int quantity;
    private Random random;
    private DecimalFormat decimalFormat;

    public Stock(String name) {
        this.name = name;
        this.random = new Random();
        this.price = generateRandomPrice();
        this.quantity = 0;
        this.decimalFormat = new DecimalFormat("#0.000");
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getFormattedPrice() {
        return decimalFormat.format(price);
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPriceChange() {
        double change = random.nextDouble() * 10 - 5;
        return Double.parseDouble(decimalFormat.format(change));
    }

    public void updatePrice() {
        double priceChange = getPriceChange();
        price += priceChange;
    }

    public void buy(int quantity) {
        this.quantity += quantity;
    }

    public boolean sell(int quantity) {
        if (this.quantity >= quantity) {
            this.quantity -= quantity;
            return true;
        }
        return false;
    }

    private double generateRandomPrice() {
        return random.nextDouble() * 1000 + 1;
    }
    public double getCurrentPrice() {
        // Mendapatkan harga saham saat ini dengan angka acak antara 1 dan 1000
        double currentPrice = random.nextDouble() * 1000 + 1;
        return currentPrice;
    }


    public String getFormattedPrice(double price) {
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.000");
        return "Rp. " + decimalFormat.format(price);
    }

}
